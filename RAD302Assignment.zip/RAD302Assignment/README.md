###Band Application for RAD Assessment

###Created by Stephen Dunne

This is my project for RAD302.

Comments are written throughout the code to explain why I went with what I did.


###My goals for this assessment are to:

* Have a list of bands that you can click into. 
* GoogleMaps will then show you their next gig location.
* Clicking into a bands album will play you the albums number 1 hit on youtube.